

// Functions developed by the OnLineHelp Team to allow the HelpSystem to always show 
// the entry in the table of contents corresponding to the topic being viewed.

function leftTrim(sString){
	while (sString.substring(0,1) == ' '){
		sString = sString.substring(1, sString.length);
	}
	return sString;
}

function rightTrim(sString){
	while (sString.substring(sString.length-1, sString.length) == ' '){
		sString = sString.substring(0,sString.length-1);
	}
	return sString;
}

function trimAll(sString){
	while (sString.substring(0,1) == ' '){
		sString = sString.substring(1, sString.length);
	}
	while (sString.substring(sString.length-1, sString.length) == ' '){
		sString = sString.substring(0,sString.length-1);
	}
	return sString;
}

function findLinkInTOC(linkURL, tocRoot){
	var ul = tocRoot;
	
	if (!ul.childNodes || ul.childNodes.length == 0) return null;
	for (var itemi=0;itemi<ul.childNodes.length;itemi++) {
		 var item = ul.childNodes[itemi];
		if (item.nodeName == "LI") {
 
			 var a;
			 var subul;
			 subul = "";
 
			 // Look in each LI child node for A or UL tags
			 for (var sitemi=0;sitemi<item.childNodes.length;sitemi++) {
				var sitem = item.childNodes[sitemi];
				switch (sitem.nodeName) {
						case "A":
							a = sitem;
							break;
					 // Found a UL - this is a book node
						case "UL":
							if (sitem.childNodes.length > 0)
							{
								if (trimAll(sitem.innerHTML).length > 0) {
									subul = sitem;
									break;
								}
							}
				 }
			 }

			// Now a has the link and subul has the sublist
			
			var unHref = a.href;
			// Tomar solo desde la �ltima "/" en adelante:
			var pos = unHref.lastIndexOf("/");
			if (pos > 0)
				unHref = unHref.substr(pos+1);
			
			if (unHref == linkURL)
				return a;
			else{
				// Recursive call may return result or null. If null, continue searching in other sibling LIs.
				var result = findLinkInTOC(linkURL, subul);
				if (result != null)
					return result;
			}	
											
		}
	}
	return null;
}

// Opens the TOC so that the route to the specified link is shown. This method receives an Anchor HTML element.
function showLinkInTOC(link){
      
	var A = link;
	if (A.nodeName != "A") return;
	
	var LI = link.parentNode;
	if (LI.nodeName != "LI") return;

	// LI's parent is an UL:
	var UL = LI.parentNode;
	if (UL.nodeName != "UL") return;
	
	// UL's parent is parent LI in the TOC
	var UlEsRaiz = false;
	var parentLI = UL.parentNode;
	if (parentLI.nodeName != "LI") 
		UlEsRaiz = true;
	
	// Find parentLI's Anchor:
	var parentA;
	if (!UlEsRaiz) {
		for (var sitemi=0;sitemi<parentLI.childNodes.length;sitemi++) {
			var sitem = parentLI.childNodes[sitemi];
			if (sitem.nodeName == "A")
				parentA = sitem;
		}	

		if (parentA != null)
			showLinkInTOC(parentA);
	}
	//A.style.background="#ffa54a";
	processUL(UL);
	if (isBook(A.parentNode))
		A.onclick();	
}

//Receives an LI
function isBook(item){

	for (var sitemi=0;sitemi<item.childNodes.length;sitemi++) {
		var sitem = item.childNodes[sitemi];
		switch (sitem.nodeName) {
			// Found a UL - this is a book node
			case "UL":
				if (sitem.childNodes.length > 0)
				{
					if (trimString(sitem.innerHTML).length > 0) {
						return true;
					}
				}
		}
	}
	return false;			
}
	
var highlightedLink = null;

function highlightLink(a){
	if (highlightedLink != null)
		highlightedLink.style.backgroundColor = "";
	highlightedLink = a;
	a.style.backgroundColor = tocHighlightColor;//"#ffa54a";
}

function setNodesOnClick(rootUL){

	if (!rootUL.childNodes || rootUL.childNodes.length == 0) return null;
	
	// Search for LIs of this UL
	for (var i=0;i<rootUL.childNodes.length;i++) {
		var LI = rootUL.childNodes[i];
		if (LI.nodeName == "LI") {
			// Search for Anchor element:
				for (var itemi=0;itemi<LI.childNodes.length;itemi++) {
					var item = LI.childNodes[itemi];
					switch (item.nodeName) {
							case "A":
								if (!isBook(item.parentNode))
									item.onclick = nodeClick;
								break;
						 // Found a UL - this is a book node
							case "UL":
								if (item.childNodes.length > 0)
								{
									if (trimString(item.innerHTML).length > 0) {
										setNodesOnClick(item);
										break;
									}
								}
					 }
				}
		}
	}
}

function nodeClick(e){
	highlightLink(this);
}

// Processes OnLoad event for the content frame. Receives the webToc frame.
function TOCHighlightLoad(){

	// If the user uses the TOC to view a topic, then this method will be fired from "cntNavtoc" frame, else, it will be fired from "webcontent" frame
	var theTocFrame = null;
	if (this.name == "webcontent")
		theTocFrame = parent.frames['webnavbar'].frames['cntNavtoc'];
	else
		return
		//theTocRoot = documentElement("tocroot");
		
	var newContentURL = this.location.href;
    var pos = newContentURL.lastIndexOf("/");
    if (pos > 0)
		newContentURL = newContentURL.substr(pos+1);

	// Access webtoc's instance of TOCHighlight to check if the Anchor pointing to the new content is already highlighted
	var currentTOCHihlightedURL = theTocFrame.highlightedLink.href
	pos = currentTOCHihlightedURL.lastIndexOf("/");
    if (pos > 0)
		currentTOCHihlightedURL = currentTOCHihlightedURL.substr(pos+1);	
	if (currentTOCHihlightedURL != newContentURL){
		// Show the topic in the TOC, but if it is a book, do not open it. If we call to open the book at this point,
		// then the user will never be able to close the book and this will lead to further bugs.
		theTocFrame.showTopicInToc(newContentURL);
	}
}

